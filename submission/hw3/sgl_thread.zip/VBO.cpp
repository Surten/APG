#include "VBO.h"

Vertex operator*(float c, Vertex& v){
    return Vertex{c * v.x, c * v.y, c * v.z, v.w};
}

Vertex operator*(Vertex& v, float c){
    return Vertex{c * v.x, c * v.y, c * v.z, v.w};
}



void Viewport::CreateViewportMatrix(){
    viewportMatrix.matrix[0] = width * 0.5f;
    viewportMatrix.matrix[3] = x + width * 0.5f;
    viewportMatrix.matrix[5] = height * 0.5f;
    viewportMatrix.matrix[7] = y + height * 0.5f;
    viewportMatrix.matrix[10] = 1;
    viewportMatrix.matrix[15] = 1;
}

void VBO::InsertVertex(float x, float y, float z, float w)
{
    Vertex v(x,y,z,w);
    if(allocated == currIndex){
        vertex_buffer.push_back(v);
        allocated++;
        currIndex++;
    }else{
        vertex_buffer.at(currIndex++) = v;
    }

}

void VBO::InsertVertex(Vertex v){

    if(allocated == currIndex){
        vertex_buffer.push_back(v);
        allocated++;
        currIndex++;
    }else{
        vertex_buffer.at(currIndex++) = v;
    }
}

void VBO::ClearVBO(){
    currIndex = 0;
    //do I need to erase everything??
    // feels like I can just override it
}

size_t VBO::GetSize(){
    return currIndex;
}

VBO::VBO(){}
VBO::~VBO(){}

